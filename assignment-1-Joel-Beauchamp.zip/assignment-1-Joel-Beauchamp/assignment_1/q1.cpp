#include <iostream>

using namespace std; 


int main() {

    int a; 
    cout << "enter a number" << endl; 
    cin >> a; 
    cout << "output: " << a * a << endl; 

    return 0; 


}


