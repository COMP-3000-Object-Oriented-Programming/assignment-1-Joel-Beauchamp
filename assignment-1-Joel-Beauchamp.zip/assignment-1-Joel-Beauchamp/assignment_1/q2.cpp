#include <iostream>

using namespace std; 

int main(){

    double first = 10; 
    int second = 15; 

    cout << "The first number is: " << first << " " << "The second number is: " << second << endl ; 

    return 0; 
}